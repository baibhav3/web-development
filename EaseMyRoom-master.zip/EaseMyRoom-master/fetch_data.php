<?php
require('./Admin/inc/db_config.php');
require('./Admin/inc/essentials.php');

session_start();
if(isset($_POST["action"]))
{
    $query = $con->query("SELECT * FROM rooms");
    if(isset($_POST["minimum_price"], $_POST["maximum_price"]) && !empty($_POST["minimum_price"]) && !empty($_POST["maximum_price"]))
    {
        $query = $con->query("SELECT * FROM rooms WHERE price BETWEEN '".$_POST["minimum_price"]."' AND '".$_POST["maximum_price"]."'");
    }
    $total_row = mysqli_num_rows($query);
    $output = '';
    if($total_row > 0){
        while ($row = $query ->fetch_object()) {

         
        // get facilities of room
       $fac_count = 0;

        $fac_q = $con->query("SELECT f.name, f.id FROM `facilities` f INNER JOIN `room_facilities` rfac ON f.id = rfac.facilities_id WHERE rfac.room_id = '$row->id'");
        $facilities_data = "";
        while($fac_row = $fac_q ->fetch_object()){
            $facilities_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fac_row->name</span>";
        }

       // get features of room
       $fea_count = 0;
       $fea_q = $con->query("SELECT f.name, f.id FROM `features` f INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE rfea.room_id = '$row->id'");
       $features_data = "";
       while($fea_row = $fea_q->fetch_object()){
           $features_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fea_row->name</span>";

       }
      
       // get thumbnail of image
       $room_thumb = ROOMS_IMG_PATH."thumbnail.jpg";
       $thumb_q = $con->query("SELECT * FROM `room_image` WHERE `room_id`='$row->id' AND `thumb`='1'");
       
       if(mysqli_num_rows($thumb_q)>0){
           $thumb_res = $thumb_q ->fetch_object();
           $room_thumb = ROOMS_IMG_PATH.$thumb_res->image;
       }


       $rating ="";
       for ($i=0; $i< $row->rating; $i++) { 
   
         $rating.= " <i class='bi bi-star-fill text-warning'></i>";

       }



            $output .= "    
            <div class='card mb-4 border-0 shadow'>
                <div class='row g-0 p-3 align-items-center'>
                    <div class='col-lg-5 col-md-4 mb-lg-0 mb-md-0 mb-3'>
                    <a href = 'room_details.php?id=$row->id'> <img src='$room_thumb' class='img-fluid rounded'> </a>
                    </div>
                    <div class='col-lg-5 col-md-6 px-lg-3 px-md-3 px-0'>
                        <h5 class='mb-3'>$row->name<br>
                        <span class='text-sm'>$rating</span>
                        
                        </h5>
                        
                        <div class='features mb-md-2 mb-3'>
                            <h6 class='mb-1'>Features</h6>
                                $features_data
                        </div>
                        <div class='facilities mb-md-2 mb-3'>
                            <h6 class='mb-1'>Facilities</h6>
                            $facilities_data
                        </div>
                        <div class='guests'>
                            <h6 class='mb-1'>Rooms</h6>
                            <span class='badge rounded-pill bg-light text-dark text-wrap'>$row->sharing Sharing</span>
                        </div>
                    </div>
                    <div class='col-md-2 mt-lg-0 mt-md-0 mt-4 text-center'>
                        <h6 class='mb-4'>₹ $row->price per months</h6>
                        <button onclick='checkLoginToBook(1,$row->id)' class='btn btn-sm w-100 text-white custom-bg shadow-none mb-2'>Book Now</button>
                        <button onclick='checkLoginToVisit(1,$row->id)' class='btn btn-sm w-100 text-white custom-bg shadow-none mb-2'>Schedule Visit</button>
                        <a href='room_details.php?id=$row->id' class='btn btn-sm w-100 btn-outline-dark shadow-none'>More Details</a>
                    </div>
                </div>
            </div>" ;
        }
    }else{
        $output = '<h3>No Data Found</h3>';
    }
    echo $output;
}

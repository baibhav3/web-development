<?php 

require('../Admin/inc/db_config.php');
require('../Admin/inc/essentials.php');
session_start();

if(isset($_POST['book'])){
    $data = filteration($_POST);

    $query = "INSERT INTO `booking`(`uid`, `room_id`, `name`, `phonenum`, `address`, `visit_from`, `visit_to`) VALUES (?,?,?,?,?,?,?)";

    $values = [$_SESSION['uId'],$_SESSION['roomId'],$data['name'],$data['phonenum'],$data['address'],$data['visit_from'],$data['visit_to']];

    if(insert($query,$values,'iisssss')){
        echo 1;
    }
    else{
        echo 'ins_failed';
    }

}

if(isset($_POST['remove']))
{   
    $frm_data = filteration($_POST) ;

    $res= delete("DELETE FROM `booking` WHERE `id`=?",[$frm_data['id']],'i');

    if($res){
      echo 1;
    }
    else{
      echo 0;
    }  

}



?>
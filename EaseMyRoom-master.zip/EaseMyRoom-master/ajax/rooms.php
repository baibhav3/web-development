<?php
require('../Admin/inc/db_config.php');
require('../Admin/inc/essentials.php');

session_start();

if(isset($_GET['fetch_rooms'])){

    

    // facilities
    $facility_list = json_decode($_GET['facility_list'],true);
    $category_list = json_decode($_GET['category_list'],true);
    $features_list = json_decode($_GET['features_list'],true);

    // count no of rooms 
    $count_room = 0;
    $output = "";

    // fetching settings table for shhutdown value 
    $setting_q = "SELECT * FROM `settings` WHERE `sr_no`=1";
    $setting_r = mysqli_fetch_assoc(mysqli_query($con,$setting_q));

    // query for room cards 
    $room_res = select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=? ORDER BY `id` DESC",[1,0],'ii');

    if($_GET['location']!=''){
        $room_res = select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=? AND `location` LIKE ? ORDER BY `id` DESC",[1,0,"%$_GET[location]%"],'iis');
    }

    while($room_data = mysqli_fetch_assoc($room_res)){

         // get category of room
        $cat_count = 0;

         $cat_q = mysqli_query($con,"SELECT f.name, f.id FROM `category` f INNER JOIN `room_category` rfac ON f.id = rfac.category_id WHERE rfac.room_id = '$room_data[id]'");
         while($cat_row = mysqli_fetch_assoc($cat_q)){
            if(in_array($cat_row['id'],$category_list['category_a'])){
                $cat_count++;
            }
         }

         if(count($category_list['category_a'])!=$cat_count){
            continue;
         }
         
         // get facilities of room
        $fac_count = 0;

         $fac_q = mysqli_query($con,"SELECT f.name, f.id FROM `facilities` f INNER JOIN `room_facilities` rfac ON f.id = rfac.facilities_id WHERE rfac.room_id = '$room_data[id]'");
         $facilities_data = "";
         while($fac_row = mysqli_fetch_assoc($fac_q)){
            if(in_array($fac_row['id'],$facility_list['facilities'])){
                $fac_count++;
            }
             $facilities_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fac_row[name]</span>";
         }

         if(count($facility_list['facilities'])!=$fac_count){
            continue;
         }

        // get features of room
        $fea_count = 0;
        $fea_q = mysqli_query($con,"SELECT f.name, f.id FROM `features` f INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE rfea.room_id = '$room_data[id]'");
        $features_data = "";
        while($fea_row = mysqli_fetch_assoc($fea_q)){
            if(in_array($fea_row['id'],$features_list['features_a'])){
                $fea_count++;
            }
            $features_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fea_row[name]</span>";

        }
        if(count($features_list['features_a'])!=$fea_count){
            continue;
         }
       
        // get thumbnail of image
        $room_thumb = ROOMS_IMG_PATH."thumbnail.jpg";
        $thumb_q = mysqli_query($con,"SELECT * FROM `room_image` WHERE `room_id`='$room_data[id]' AND `thumb`='1'");
        
        if(mysqli_num_rows($thumb_q)>0){
            $thumb_res = mysqli_fetch_assoc($thumb_q);
            $room_thumb = ROOMS_IMG_PATH.$thumb_res['image'];
        }


        $book_btn = "";
        $book_visit = "";
        if(!$setting_r['shutdown']){
            $login=0;
            if(isset($_SESSION['login']) && $_SESSION['login']==true){
                $login = 1;
            }
            $book_btn = "<button onclick='checkLoginToBook($login,$room_data[id])' class='btn btn-sm w-100 text-white custom-bg shadow-none mb-2'>Book Now</button>";
            $book_visit = "<button onclick='checkLoginToVisit($login,$room_data[id])' class='btn btn-sm w-100 text-white custom-bg shadow-none mb-2'>Schedule Visit</button>";
        }
        if(!$setting_r['shutdown']){
        }

        $rating ="";
        for ($i=0; $i< $room_data['rating']; $i++) { 
    
          $rating.= " <i class='bi bi-star-fill text-warning'></i>";

        }


        // print room card
        $output.= "
            <div class='card mb-4 border-0 shadow'>
                <div class='row g-0 p-3 align-items-center'>
                    <div class='col-lg-5 col-md-4 mb-lg-0 mb-md-0 mb-3'>
                    <a href = 'room_details.php?id=$room_data[id]'> <img src='$room_thumb' class='img-fluid rounded'> </a>
                    </div>
                    <div class='col-lg-5 col-md-6 px-lg-3 px-md-3 px-0'>
                        <h5 class='mb-3'>$room_data[name]<br>
                        <span class='text-sm'>$rating</span>
                        
                        </h5>
                        
                        <div class='features mb-md-2 mb-3'>
                            <h6 class='mb-1'>Features</h6>
                                $features_data
                        </div>
                        <div class='facilities mb-md-2 mb-3'>
                            <h6 class='mb-1'>Facilities</h6>
                            $facilities_data
                        </div>
                        <div class='guests'>
                            <h6 class='mb-1'>Rooms</h6>
                            <span class='badge rounded-pill bg-light text-dark text-wrap'>$room_data[sharing] Sharing</span>
                        </div>
                    </div>
                    <div class='col-md-2 mt-lg-0 mt-md-0 mt-4 text-center'>
                        <h6 class='mb-4'>₹ $room_data[price] per months</h6>
                        $book_btn
                        $book_visit
                        <a href='room_details.php?id=$room_data[id]' class='btn btn-sm w-100 btn-outline-dark shadow-none'>More Details</a>
                    </div>
                </div>
            </div>
            ";

            $count_room++;
    }


    if($count_room>0){
        echo $output;
    }
    else{
        echo "<h3 class='text-center text-danger'> No rooms to show!</h3>";
    }

}



?>
<?php 
require('../Admin/inc/db_config.php');
require('../Admin/inc/essentials.php');

if(isset($_POST['add_visit']))
{
 
  $frm_data = filteration($_POST);
  $flag = 0;

  $q1 = "INSERT INTO `visit`(`date`, `name`, `number`, `email`) VALUES (?,?,?,?)";
  $values = [$frm_data['date'],$frm_data['name'],$frm_data['num'],$frm_data['email']];
  if(insert($q1,$values,'ssss')){
    $flag = 1;
  }
  
  if($flag){
    echo 1;
  }
  else{
    echo 0;
  }
}




?>
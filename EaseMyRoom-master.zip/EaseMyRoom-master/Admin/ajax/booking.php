<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();


  if(isset($_POST['get_users']))
  {
    $res = selectAll('booking');
    $i=1;
    $data = "";

    while($row = mysqli_fetch_assoc($res))
    {


      $date = date("d-m-Y",strtotime($row['visit_from'])); 
      $date2 = date("d-m-Y",strtotime($row['visit_to'])); 
   
     
     $data.="
     <tr class='align-middle'>
        <td>$i</td>
        <td>$row[name]</td>
        <td>$row[phonenum]</td>
        <td>$row[address]</td>
        <td>$date</td>
        <td>$date2</td>
        <td>$row[room_id]</td>
        <td>
            <button type='button' onclick='remove_user($row[id])' class='btn btn-danger shadow-none btn-sm'>
              <i class='bi bi-trash me-1'></i>
            </button>
        </td>
      </tr>  
     ";
     $i++;
      
    }
    echo $data;
  }


  if(isset($_POST['remove_user']))
{   
    $frm_data = filteration($_POST) ;

    $res= delete("DELETE FROM `booking` WHERE `id`=?",[$frm_data['user_id']],'i');

    if($res){
      echo 1;
    }
    else{
      echo 0;
    }  

}


if(isset($_POST['search_user']))
{
  $frm_data = filteration($_POST);
  $query = "SELECT * FROM `booking` WHERE `name` LIKE ?";
  $res = select($query,["%$frm_data[name]%"],'s');
  $i=1;
  $data = "";

  while($row = mysqli_fetch_assoc($res))
  {


    $date = date("d-m-Y",strtotime($row['visit_from'])); 
    $date2 = date("d-m-Y",strtotime($row['visit_to'])); 
 
   
   $data.="
   <tr class='align-middle'>
      <td>$i</td>
      <td>$row[name]</td>
      <td>$row[phonenum]</td>
      <td>$row[address]</td>
      <td>$date</td>
      <td>$date2</td>
      <td>$row[room_id]</td>
      <td>
          <button type='button' onclick='remove_user($row[id])' class='btn btn-danger shadow-none btn-sm'>
            <i class='bi bi-trash me-1'></i>
          </button>
      </td>
    </tr>  
   ";
   $i++;
    
  }
  echo $data;
}



<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
adminLogin();


if(isset($_POST['add_patnar']))
{   
    $frm_data = filteration($_POST) ;
    $q = "INSERT INTO `pg_patnar`(`name`,`password`,`address`,`phonenum`) VALUES (?,?,?,?)";
    $values = [$frm_data['username'],$frm_data['password'],$frm_data['address'],$frm_data['phone_no']];
    $res = insert($q,$values,'ssss');
    echo $res;
}

  if(isset($_POST['get_patnar']))
  {
    $res = selectAll('pg_patnar');
    $i=1;
    $data = "";

    while($row = mysqli_fetch_assoc($res))
    {

      if($row['status']==1){
        $status = "<button onclick='toggle_status($row[id],0)' class='btn btn-dark btn-sm shadow-none'>Active</button>";
      }
      else{
        $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-danger btn-sm shadow-none'>Inactive</button>";
      }
   
     
     $data.="
     <tr class='align-middle'>
        <td>$i</td>
        <td>$row[name]</td>
        <td>$row[password]</td>
        <td>$row[address]</td>
        <td>$row[phonenum]</td>
        <td>$status</td>
        <td>
            <button type='button' onclick='remove_patnar($row[id])' class='btn btn-danger shadow-none btn-sm'>
              <i class='bi bi-trash me-1'></i>
            </button>
        </td>
      </tr>  
     ";
     $i++;
      
    }
    echo $data;
  }

  if(isset($_POST['toggle_status']))
  {
   $frm_data = filteration($_POST);
   $q = "UPDATE `pg_patnar` SET `status`=? WHERE `id`=?";
   $v=[$frm_data['value'],$frm_data['toggle_status']];
   if(update($q,$v,'ii')){
    echo 1;
   }
   else{
    echo 0;
   }
   
  }


  if(isset($_POST['remove_patnar']))
{   
    $frm_data = filteration($_POST) ;

    $res= delete("DELETE FROM `pg_patnar` WHERE `id`=?",[$frm_data['patnar_id']],'i');

    if($res){
      echo 1;
    }
    else{
      echo 0;
    }  

}


if(isset($_POST['search_patnar']))
{
  $frm_data = filteration($_POST);
  $query = "SELECT * FROM `pg_patnar` WHERE `name` LIKE ?";
  $res = select($query,["%$frm_data[name]%"],'s');
  $i=1;
  $data = "";

  while($row = mysqli_fetch_assoc($res))
  {

    if($row['status']==1){
      $status = "<button onclick='toggle_status($row[id],0)' class='btn btn-dark btn-sm shadow-none'>Active</button>";
    }
    else{
      $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-danger btn-sm shadow-none'>Inactive</button>";
    }

   
 
   
   $data.="
   <tr class='align-middle'>
        <td>$i</td>
        <td>$row[name]</td>
        <td>$row[password] sq. ft.</td>
        <td>$row[address]</td>
        <td>$row[phonenum]</td>
        <td>$status</td>
        <td>
            <button type='button' onclick='remove_patnar($row[id])' class='btn btn-danger shadow-none btn-sm'>
              <i class='bi bi-trash me-1'></i>
            </button>
        </td>
    </tr>  
   ";
   $i++;
    
  }
  echo $data;
}



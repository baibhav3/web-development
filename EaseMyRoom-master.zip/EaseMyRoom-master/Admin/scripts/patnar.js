    
       let patnar_s_form = document.getElementById('patnar_s_form');

       patnar_s_form.addEventListener('submit', function(e) {
        e.preventDefault();
        add_patnar();
    })
    function add_patnar() {
        let data = new FormData();
        data.append('username', patnar_s_form.elements['username'].value);
        data.append('password', patnar_s_form.elements['password'].value);
        data.append('address', patnar_s_form.elements['address'].value);
        data.append('phone_no', patnar_s_form.elements['phone_no'].value);
        data.append('add_patnar', '');

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "ajax/patnar.php", true);


        xhr.onload = function() {
            var myModal = document.getElementById('patnar-s');
            var modal = bootstrap.Modal.getInstance(myModal);
            modal.hide();
            if (this.responseText == 1) {
                alert('success', 'New Patnar Added Successfully!');
                patnar_s_form.elements['username'].value = '';
                patnar_s_form.elements['password'].value= '';
                patnar_s_form.elements['address'].value = '';
                patnar_s_form.elements['phone_no'].value = '';
                get_patnar();
            } else {
                alert('error', 'Server Down!');
            }
        }


        xhr.send(data);
    }
       
       function get_patnar() {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/patnar.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                document.getElementById('patnar-data').innerHTML = this.responseText;
            }


            xhr.send('get_patnar');
        }

        function toggle_status(id, val) {
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/patnar.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                if (this.responseText == 1) {
                    alert('success', 'Status toggled!');
                    get_patnar();
                } else {
                    alert('error', 'Server down!');

                }
            }


            xhr.send('toggle_status=' + id + '&value=' + val);
        }


        function remove_patnar(patnar_id){
            if(confirm("Are you sure, You want to delete this patnar")){

                let data = new FormData();
                data.append('patnar_id',patnar_id);
                data.append('remove_patnar', '');
    
                let xhr = new XMLHttpRequest();
                xhr.open("POST", "ajax/patnar.php", true);
    
    
                xhr.onload = function() {
                   
                    if (this.responseText == 1) {
                        alert('success', 'patnar Removed');
                        get_patnar();
                    } 
                    else {
                        alert('error', 'Server Down!');
                    }
                }
    
                xhr.send(data);
            }
        }


        function search_patnar(username){
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/patnar.php", true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');


            xhr.onload = function() {
                document.getElementById('patnar-data').innerHTML = this.responseText;
            }


            xhr.send('search_patnar&name='+username);
        }





        window.onload = function() {
            get_patnar();
        }
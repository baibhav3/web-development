<?php
require('./inc/essentials.php');
require('./inc/db_config.php');
adminLogin();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Patnar</title>
    <?php require("./inc/links.php"); ?>
</head>

<body class="bg-light">
    <?php require('./inc/header.php'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden" id="main-content">
                <h3 class="mb-4">Patnars</h3>
                <!-- patnar section  -->
                <div class="card border-0 shadow mb-4">
                    <div class="card-body">

                        <div class="text-end mb-4 d-flex ">
                            <input type="text" oninput="search_patnar(this.value)" class="form-control shadow-none w-25 ms-auto me-2" placeholder="Type to Search">
                            <button type="button" class="btn btn-dark shadow-none btn-sm" data-bs-toggle="modal" data-bs-target="#patnar-s">
                                <i class="bi bi-plus-square me-1"></i> ADD
                            </button>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover border text-center">
                                <thead>
                                    <tr class="bg-dark text-light">
                                        <th scope="col">#</th>
                                        <th scope="col">User Name</th>
                                        <th scope="col">Password</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Phone No</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody id="patnar-data">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- patnar section end  -->
            </div>
        </div>
    </div>
      <!-- patner modal section  -->
      <div class="modal fade" id="patnar-s" data-bs-backdrop="static" data-bs-keyboard="true" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <form method="POST" id="patnar_s_form">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Patnar</h5>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Username</label>
                            <input type="text" name="username" class="form-control shadow-none" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Password</label>
                            <input type="text" name="password" class="form-control shadow-none" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Address</label>
                            <input type="text" name="address" class="form-control shadow-none" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Phone No</label>
                            <input type="text" name="phone_no" class="form-control shadow-none" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn text-secondary shadow-none" data-bs-dismiss="modal">CANCEL</button>
                        <button type="submit" class="btn custom-bg text-white shadow-none">SAVE</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- Features modal section end  -->

    <?php require("./inc/scripts.php"); ?>
    <script src="./scripts/patnar.js"></script>


    
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room - BOOKINGS </title>
    <?php require("./includes/links.php"); ?>
</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php");
    if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
        redirect('rooms.php');
    }

    ?>
    <!-- nav-bar-end  -->




    <div class="container">
        <div class="row">
            <div class="col-12 my-5 px-4">
                <h2 class="fw-bold">BOOKINGS</h2>
                <div style="font-size: 14px;">
                    <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                    <span class="text-secondary"> > </span>

                    <a href="#" class="text-secondary text-decoration-none">BOOKINGS</a>
                </div>
            </div>
            <?php

            $query = "SELECT * FROM `booking` WHERE `uid` =? ORDER BY `id` DESC";
            $result = select($query, [$_SESSION['uId']], 'i');
            while ($data = mysqli_fetch_assoc($result)) {
                $date = date("d-m-Y", strtotime($data['visit_from']));
                $date2 = date("d-m-Y", strtotime($data['visit_to']));

                $q = select("SELECT * FROM `rooms` WHERE `id` =?", [$data['room_id']], 'i');
                while ($room_data = mysqli_fetch_assoc($q)) {
                    echo <<<bookings
                        <div class='col-md-4 px-4 mb-4'>
                            <div class = 'bg-white p-3 rounded shadow-sm'>
                                <h5 class='fw-bold'>$room_data[name]</h5>
                                <p>₹$room_data[price] per months</p>
                                <p>
                                    <b>Visit Date</b><br>
                                    <b> From: </b> $date<br>
                                    <b> To: </b> $date2
                                </p>
                                <p><b> Location: </b>$room_data[location] </p>
                                <div class="text-center my-1">
                                    <button onclick='cancle_booking($data[id])' class="btn btn-danger">CENCLE</button>
                                </div>
                            </div>
                        </div>

                    bookings;
                }
            }

            ?>




        </div>
    </div>


    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->

    <script>
        function cancle_booking(id) {
            if (confirm("Are you sure, You want to cencle this booking")) {

                let data = new FormData();
                data.append('id', id);
                data.append('remove', '');

                let xhr = new XMLHttpRequest();
                xhr.open("POST", "ajax/booking.php", true);


                xhr.onload = function() {

                    if (this.responseText == 1) {
                        alert('success', 'Cencled');
                        location.reload();
                    } else {
                        alert('error', 'Server Down!');
                    }
                }

                xhr.send(data);
            }
        }
    </script>


</body>

</html>
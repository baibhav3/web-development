<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room - CONFIRM VISIT </title>
    <?php require("./includes/links.php"); ?>
</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->
    <?php
    if (!isset($_GET['id']) || $setting_r['shutdown'] == true) {
        redirect('rooms.php');
    } else if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
        redirect('rooms.php');
    }


    $data = filteration($_GET);

    $room_res = select("SELECT * FROM `rooms` WHERE `id`=? AND `status`=? AND `removed`=?", [$data['id'], 1, 0], 'iii');
    if (mysqli_num_rows($room_res) == 0) {
        redirect('rooms.php');
    }
    $room_data = mysqli_fetch_assoc($room_res);

    $_SESSION['roomId']=$room_data['id'];

    $_SESSION['room'] = [
        "id" => $room_data['id'],
        "name" => $room_data['name'],
        "price" => $room_data['price'],
    ];

    $user_res = select("SELECT * FROM `user_cred` WHERE `id`=? LIMIT 1", [$_SESSION['uId']], "i");
    $user_data = mysqli_fetch_assoc($user_res);



    ?>



    <div class="container">
        <div class="row">
            <div class="col-12 my-5 px-4 mb-4">
                <h2 class="fw-bold">CONFIRM BOOKING</h2>
                <div style="font-size: 14px;">
                    <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                    <span class="text-secondary"> > </span>
                    <a href="rooms.php" class="text-secondary text-decoration-none">ROOMS</a>
                    <span class="text-secondary"> > </span>
                    <a href="rooms.php" class="text-secondary text-decoration-none">CONFIRM</a>
                </div>

            </div>

            <div class="col-lg-7 col-md-12 px-4">
                <?php
                // get thumbnail of image
                $room_thumb = ROOMS_IMG_PATH . "thumbnail.jpg";
                $thumb_q = mysqli_query($con, "SELECT * FROM `room_image` WHERE `room_id`='$room_data[id]' AND `thumb`='1'");

                if (mysqli_num_rows($thumb_q) > 0) {
                    $thumb_res = mysqli_fetch_assoc($thumb_q);
                    $room_thumb = ROOMS_IMG_PATH . $thumb_res['image'];
                }
                echo <<<data
                        <div class="card p-3 shadow-sm rounded">
                            <img src="$room_thumb" class="img-fluid rounded mb-3">
                            <h5>$room_data[name]<h5>
                            <h6>₹ $room_data[price] per month<h6>
                        </div>

                    data;

                ?>



            </div>


            <div class="col-lg-5 col-md-12 px-4">
                <div class="card mb-4 border-0 shadow rounded-3">
                    <div class="card-body">
                        <form action="#" id="booking_form">
                            <h6 class="mb-3">BOOKING DETAILS</h6>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="name" value="<?php echo $user_data['name'] ?>" class="form-control shadow-none" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="number" name="phonenum" class="form-control shadow-none" value="<?php echo $user_data['phonenum'] ?>" required>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label">Address</label>
                                    <textarea class="form-control shadow-none" name="address" rows="4"><?php echo $user_data['address'] ?></textarea>
                                </div>
                                <div class="col-md-12 mb-4">
                                    <label class="form-label">Visit Date</label>
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">From</label>
                                            <input type="date" name="date1" class="form-control shadow-none" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">To</label>
                                            <input type="date" name="date2" class="form-control shadow-none" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mb-3">
                                    <button type="submit" class="btn w-100 text-white custom-bg shadow-none mb-2">Submit</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>



        </div>
    </div>


    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->

    <script>
        let booking_form = document.getElementById('booking_form');
        booking_form.addEventListener('submit',(e)=>{
        e.preventDefault();

            let data = new FormData();
            data.append('name', booking_form.elements['name'].value);
            data.append('phonenum', booking_form.elements['phonenum'].value);
            data.append('address', booking_form.elements['address'].value);
            data.append('visit_from', booking_form.elements['date1'].value);
            data.append('visit_to', booking_form.elements['date2'].value);
            // data.append('roomId', $_SESSION['roomId']);
            
            data.append('book', '');
       
            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/booking.php", true);

            xhr.onload = function() {
                if(this.responseText=='1'){
                    window.open('./bookings.php')
                    alert('success','BOOKING VISIT SUCCESSFULLY!');
                }
                else{
                    alert('error','Server Down!');
                }
            }


            xhr.send(data);
    });
    </script>


</body>

</html>
<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonts">
    OUR TESTIMONIALS
</h2>
<div class="container mt-5">
    <div class="swiper swiper-testimonials">
        <div class="swiper-wrapper mb-5">
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>
            <div class="swiper-slide bg-white p-4">
                <div class="profile d-flex align-items-center mb-3">
                    <img src="./images/facilities/massage.svg" width="30px">
                    <h6 class="m-0 ms-2">Random users1</h6>
                </div>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus molestiae harum reprehenderit voluptate alias culpa dignissimos nemo reiciendis quo. Consequatur.
                </p>
                <div class="rating">
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                    <i class="bi bi-star-fill text-warning"></i>
                </div>
            </div>


        </div>
        <div class="swiper-pagination"></div>
    </div>
    <div class="col-lg-12 text-center mt-5">
        <a href="./about.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">Know More >>></a>
    </div>

</div>
<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonts">
    OUR ROOMS
</h2>
<div class="container">
    <div class="row">

        <?php
            
            $room_res = select("SELECT * FROM `rooms` WHERE `status`=? AND `removed`=? ORDER BY `id` DESC LIMIT 3",[1,0],'ss');
            while($room_data = mysqli_fetch_assoc($room_res)){

                // get features of room
                $fea_q = mysqli_query($con,"SELECT f.name FROM `features` f INNER JOIN `room_features` rfea ON f.id = rfea.features_id WHERE rfea.room_id = '$room_data[id]'");
                $features_data = "";
                while($fea_row = mysqli_fetch_assoc($fea_q)){
                    $features_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fea_row[name]</span>";

                }
                // get facilities of room
                $fac_q = mysqli_query($con,"SELECT f.name FROM `facilities` f INNER JOIN `room_facilities` rfac ON f.id = rfac.facilities_id WHERE rfac.room_id = '$room_data[id]'");
                $facilities_data = "";
                while($fac_row = mysqli_fetch_assoc($fac_q)){
                    $facilities_data.= "<span class='badge rounded-pill bg-light text-dark text-wrap me-1 mb-1'>$fac_row[name]</span>";

                }
                // get thumbnail of image
                $room_thumb = ROOMS_IMG_PATH."thumbnail.jpg";
                $thumb_q = mysqli_query($con,"SELECT * FROM `room_image` WHERE `room_id`='$room_data[id]' AND `thumb`='1'");
                
                if(mysqli_num_rows($thumb_q)>0){
                    $thumb_res = mysqli_fetch_assoc($thumb_q);
                    $room_thumb = ROOMS_IMG_PATH.$thumb_res['image'];
                }

                $book_btn = "";
                if(!$setting_r['shutdown']){
                    $login=0;
                    if(isset($_SESSION['login']) && $_SESSION['login']==true){
                        $login = 1;
                    }
                    $book_btn = "<button onclick='checkLoginToBook($login,$room_data[id])' class='btn btn-sm text-white custom-bg shadow-none'>Book Now</button>";
                }

                // get rating
                $rating ="";
                for ($i=0; $i< $room_data['rating']; $i++) { 
            
                  $rating.= " <i class='bi bi-star-fill text-warning'></i>";
        
                }
                
                // print room card
                echo <<<data

                    <div class="col-lg-4 col-md-6 my-3">
                        <div class="card border-0 shadow" style="max-width: 350px; margin: auto;">
                            <a href = "room_details.php?id=$room_data[id]"><img src="$room_thumb" class="card-img-top"></a>
            
                            <div class="card-body">
                                <h5 class="card-title">$room_data[name]</h5>
                                <h6 class="mb-3">₹ $room_data[price] per months</h6>
                                <div class="features mb-2">
                                    <h6 class="mb-1">Features</h6>
                                    $features_data
                                </div>
                                <div class="facilities mb-2">
                                    <h6 class="mb-1">Facilities</h6>
                                    $facilities_data
                                </div>
                                <div class="guests mb-2">
                                    <h6 class="mb-1">Rooms</h6>
                                    <span class="badge rounded-pill bg-light text-dark text-wrap">$room_data[sharing] Sharing</span>
                                </div>
                                <div class="rating mb-2">
                                    <h6 class="mb-1">Rating</h6>
                                    <span class="badge rounded-pill bg-light">
                                        
                                    $rating
                                    </span>
                                </div>
                                <div class="d-flex justify-content-evenly mb-1">
                                $book_btn
                                <a href="room_details.php?id=$room_data[id]" class="btn btn-sm btn-outline-dark shadow-none">More Details</a>
                                </div>
                            </div>
                        </div>
                    </div>
                data;
            }

        ?>
        <div class="col-lg-12 text-center mt-5">
            <a href="./rooms.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More Rooms >>></a>
        </div>
    </div>
</div>
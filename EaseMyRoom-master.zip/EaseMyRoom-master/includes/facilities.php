<h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-fonts">
    OUR FACILITIES
</h2>
<div class="container">
    <div class="row justify-content-evenly px-lg-0 px-md-0 px-5">

    <?php
            $res = mysqli_query($con,"SELECT * FROM `facilities` ORDER BY `id` DESC LIMIT 5");
            $path = FEATURES_IMG_PATH;
            while($row = mysqli_fetch_assoc($res)){
                echo<<<data
                    <div class="col-lg-2 col-md-2 text-center bg-white rounded shadow py-4 my-3">
                        <img src="$path$row[icon]" alt="" width="60px">
                        <h5 class="mt-3">$row[name]</h5>
                    </div>
                    

                data;
            }

    ?>

        <div class="col-lg-12 text-center mt-5">
        <a href="./facilitie.php" class="btn btn-sm btn-outline-dark rounded-0 fw-bold shadow-none">More Facilities >>></a>
        </div>
    </div>
</div>

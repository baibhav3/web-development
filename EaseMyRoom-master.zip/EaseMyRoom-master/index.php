<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room</title>
    <?php require("./includes/links.php"); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />

</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->

    <!-- carousel  -->
    <div class="container-fluide px-3 px-lg-4 mt-4">
        <div class="swiper swiper-container">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <img src="./images/carousel/img-1.svg" class="w-100 d-block" />
                </div>
                <div class="swiper-slide">
                    <img src="./images/carousel/img-2.jpg" class="w-100 d-block" />
                </div>
                <div class="swiper-slide">
                    <img src="./images/carousel/img-1.svg" class="w-100 d-block" />
                </div>
                <div class="swiper-slide">
                    <img src="./images/carousel/img3.png" class="w-100 d-block" />
                </div>
                <div class="swiper-slide">
                    <img src="./images/carousel/img-1.svg" class="w-100 d-block" />
                </div>
                <div class="swiper-slide">
                    <img src="./images/carousel/img5.png" class="w-100 d-block" />
                </div>
            </div>
        </div>
    </div>
    <!-- carousel end  -->

    <!-- Schedule a Visit -->
    <div class="container schedule-form">
        <div class="row">
            <div class="col-lg-12 bg-white shadow p-4 rounded">
                <h5 class="mb-4">
                    Schedule a Visit
                </h5>
                <form id="visit-form">
                    <div class="row align-items-end">
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500">Date</label>
                            <input type="date" name="date" class="form-control shadow-none">
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500">Name</label>
                            <input type="text" name="name" class="form-control shadow-none">
                        </div>
                        <div class="col-lg-3 mb-3">
                            <label class="form-label" style="font-weight:500">Contact No</label>
                            <input type="number" name="num" class="form-control shadow-none">
                        </div>
                        <div class="col-lg-2 mb-3">
                            <label class="form-label" style="font-weight:500">Email</label>
                            <input type="email" name="email" class="form-control shadow-none">
                        </div>
                        <div class="col-lg-1 mb-lg-3 mt-2 schedule-form-btn">
                            <button type="submit" name="visit" class="btn text-white shadow-none custom-bg">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Schedule a Visit end -->

    <!--Our Rooms card -->
    <?php include("./includes/rooms_card.php"); ?>
    <!--Our Rooms card end-->

    <!--Our facilities -->
    <?php include("./includes/facilities.php"); ?>
    <!--Our facilities end-->

    <!--Testimonials -->
    <?php include("./includes/testimonials.php"); ?>
    <!--Testimonials end-->

    <!--Reach us -->
    <?php include("./includes/reachus.php"); ?>
    <!--Reach end-->

    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->


    <!-- js -->

    <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".swiper-container", {
            spaceBetween: 30,
            effect: "fade",
            loop: true,
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            }
        });

        var swiper = new Swiper(".swiper-testimonials", {
            effect: "coverflow",
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: "auto",
            slidesPerView: "3",
            loop: true,
            coverflowEffect: {
                rotate: 50,
                stretch: 0,
                depth: 100,
                modifier: 1,
                slideShadows: false,
            },
            pagination: {
                el: ".swiper-pagination",
            },
            autoplay: {
                delay: 3500,
                disableOnInteraction: false,
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                640: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 2,
                },
                1024: {
                    slidesPerView: 3,
                },

            },

        });
    </script>
    <script>
        let visit_form = document.getElementById('visit-form');

        visit_form.addEventListener('submit', function(e) {
            e.preventDefault();
            add_visit();
        });

        function add_visit() {
            let data = new FormData();
            data.append('add_visit', '');
            data.append('date', visit_form.elements['date'].value);
            data.append('name', visit_form.elements['name'].value);
            data.append('num', visit_form.elements['num'].value);
            data.append('email', visit_form.elements['email'].value);

            let xhr = new XMLHttpRequest();
            xhr.open("POST", "ajax/visit.php", true);


            xhr.onload = function() {
              
                if (this.responseText == 1) {
                    alert('success', 'Your record Successfully!');
                    visit_form.reset();
                    // get_all_rooms();
                } else {
                    alert('error', 'Server Down!');
                }
            }


            xhr.send(data);
        }
    </script>
</body>

</html>
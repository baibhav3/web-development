<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ease My Room - ROOMS</title>
    <?php require("./includes/links.php"); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>

<body class="bg-light">

    <!-- nav-bar -->
    <?php include("./includes/header.php"); ?>
    <!-- nav-bar-end  -->
    <div class="my-5 px-4">
        <h2 class="fw-bold h-fonts text-center">OUR ROOMS</h2>
        <div class="h-line bg-dark"></div>

    </div>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 col-md-12 mb-lg-0 mb-4 ps-4">
                <nav class="navbar navbar-expand-lg navbar-light bg-white rounded shadow">
                    <div class="container-fluid flex-lg-column align-items-stretch">
                        <h4 class="mt-2">FILTERS</h4>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#filterDropdown" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse flex-column align-items-stretch mt-2" id="filterDropdown">
                            <div class="border bg-light p-3 rounded mb-3">
                                <h5 class="mb-3 d-flex align-items-center justify-content-between" style="font-size:18px;">
                                    <span>CATEGORY</span>
                                    <button id="chk_cat_btn" onclick="cat_clear()" class="btn btn-sm text-secondary d-none">Reset</button>
                                </h5>
                                <div class="d-flex">
                                    <?php

                                    $category_q = selectAll('category');
                                    while ($row = mysqli_fetch_assoc($category_q)) {
                                        echo <<<category
                                        <div class="mb-2 me-3">
                                            <input type="checkbox" onclick="fetch_rooms()" name="category" id="$row[id]" value="$row[id]" class="form-check-input shadow-none me-1">
                                            <label for="$row[id]" class="form-check-label">$row[name]</label>
                                        </div>
                                    category;
                                    }
                                    ?>
                                </div>

                            </div>
                            <div class="border bg-light p-3 rounded mb-3">
                                <h5 class="mb-3" style="font-size:18px;">LOCATION</h5>
                                <form method="post">
                                    <input type="text" name="location" class="form-control shadow-none w-100 ms-auto mb-2">
                                    <button type="submit" name="loc" class="btn btn-dark">Search</button>
                                </form>
                            </div>
                            <div class="border bg-light p-3 rounded mb-3">
                                <div class="list-group">
                                    <h3>Price</h3>
                                    <input type="hidden" id="hidden_minimum_price" value="0" />
                                    <input type="hidden" id="hidden_maximum_price" value="65000" />
                                    <p id="price_show">100 - 30000</p>
                                    <div id="price_range"></div>
                                </div>
                            </div>



                            <!-- facilities -->
                            <div class="border bg-light p-3 rounded mb-3">
                                <h5 class="mb-3 d-flex align-items-center justify-content-between" style="font-size:18px;">
                                    <span> FACILITIES</span>
                                    <button id="facilities_btn" onclick="facilities_clear()" class="btn shadow-none btn-sm text-secondary d-none">Reset</button>
                                </h5>
                                <?php

                                $facilities_q = selectAll('facilities');
                                while ($row = mysqli_fetch_assoc($facilities_q)) {
                                    echo <<<facilities
                                        <div class="mb-2">
                                            <input type="checkbox" onclick="fetch_rooms()" name="facilities" id="$row[id]" value="$row[id]" class="form-check-input shadow-none me-1">
                                            <label for="$row[id]" class="form-check-label">$row[name]</label>
                                        </div>
                                    facilities;
                                }
                                ?>
                            </div>
                            <div class="border bg-light p-3 rounded mb-3">
                                <h5 class="mb-3 d-flex align-items-center justify-content-between" style="font-size:18px;">
                                    Features
                                    <button id="features_btn" onclick="features_clear()" class="btn shadow-none btn-sm text-secondary d-none">Reset</button>
                                </h5>
                                <?php

                                $features_q = selectAll('features');
                                while ($row = mysqli_fetch_assoc($features_q)) {
                                    echo <<<features
                                        <div class="mb-2">
                                            <input type="checkbox" onclick="fetch_rooms()" name="features" id="$row[id]" value="$row[id]" class="form-check-input shadow-none me-1">
                                            <label for="$row[id]" class="form-check-label">$row[name]</label>
                                        </div>
                                        features;
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </nav>
            </div>
            <div class="col-lg-9 col-md-12 px-4 " id="rooms-data">

            </div>


        </div>
    </div>

    <script>
        let rooms_data = document.getElementById('rooms-data');
        let facilities_btn = document.getElementById('facilities_btn');

        $(document).ready(function() {
            filter_data();

            function filter_data() {
                $('#rooms-data').html('<div id="loading" style="" ></div>');
                var action = 'fetch_data';
                var minimum_price = $('#hidden_minimum_price').val();
                var maximum_price = $('#hidden_maximum_price').val();
                $.ajax({
                    url: "fetch_data.php",
                    method: "POST",
                    data: {
                        action: action,
                        minimum_price: minimum_price,
                        maximum_price: maximum_price
                    },
                    success: function(data) {
                        $('#rooms-data').html(data);
                    }
                });
            }

            $('#price_range').slider({
                range: true,
                min: 100,
                max: 50000,
                values: [100, 50000],
                step: 100,
                slide: function(event, ui) {
                    $('#price_show').html(ui.values[0] + ' - ' + ui.values[1]);
                },
                stop: function(event, ui) {
                    $('#hidden_minimum_price').val(ui.values[0]);
                    $('#hidden_maximum_price').val(ui.values[1]);
                    filter_data();
                }
            });

            // Add touch event handlers to slider handles
            $('#price_range .ui-slider-handle').on('touchstart', function(e) {
                $(this).addClass('ui-state-active');
                var thumb = $(this);
                $(document).on('touchmove.slider', function(e) {
                    var left = e.originalEvent.touches[0].pageX - $('#price_range').offset().left - (thumb.width() / 2);
                    if (left < 0) {
                        left = 0;
                    } else if (left > $('#price_range').width() - thumb.width()) {
                        left = $('#price_range').width() - thumb.width();
                    }
                    var value = Math.round(left / ($('#price_range').width() - thumb.width()) * ($('#price_range').slider('option', 'max') - $('#price_range').slider('option', 'min')) + $('#price_range').slider('option', 'min'));
                    $('#price_show').html($('#price_range').slider('values', 0) + ' - ' + $('#price_range').slider('values', 1));
                    if (thumb.hasClass('ui-slider-handle:first-child')) {
                        $('#price_range').slider('values', 0, value);
                        $('#hidden_minimum_price').val(value);
                    } else {
                        $('#price_range').slider('values', 1, value);
                        $('#hidden_maximum_price').val(value);
                    }
                    filter_data();
                });
            });
            $('#price_range .ui-slider-handle').on('touchend', function(e) {
                $(this).removeClass('ui-state-active');
                $(document).off('touchmove.slider');
            });

            // Add mouse event handlers to slider handles
            $('#price_range .ui-slider-handle').on('mousedown', function(e) {
                $(this).addClass('ui-state-active');
                var thumb = $(this);
                $(document).on('mousemove.slider', function(e) {
                    var left = e.pageX - $('#price_range').offset().left - (thumb.width() / 2);
                    if (left < 0) {
                        left = 0;
                    } else if (left > $('#price_range').width() - thumb.width()) {
                        left = $('#price_range').width() - thumb.width();
                    }
                    var value = Math.round(left / ($('#price_range').width() - thumb.width()) * ($('#price_range').slider('option', 'max') - $('#price_range').slider('option', 'min')) + $('#price_range').slider('option', 'min'));
                    $('#price_show').html($('#price_range').slider('values', 0) + ' - ' + $('#price_range').slider('values', 1));
                    if (thumb.hasClass('ui-slider-handle:first-child')) {
                        $('#price_range').slider('values', 0, value);
                        $('#hidden_minimum_price').val(value);
                    } else {
                        $('#price_range').slider('values', 1, value);
                        $('#hidden_maximum_price').val(value);
                    }
                    filter_data();
                }).on('mouseup.slider', function() {
                    $(this).removeClass('ui-state-active');
                    $(document).off('mousemove.slider');
                });
            });
        });




        function fetch_rooms() {

            let facility_list = {
                "facilities": []
            };
            let get_facilities = document.querySelectorAll('[name="facilities"]:checked');
            if (get_facilities.length > 0) {
                get_facilities.forEach((facility) => {
                    facility_list.facilities.push(facility.value);
                });
                facilities_btn.classList.remove('d-none');
            } else {
                facilities_btn.classList.add('d-none');
            }
            facility_list = JSON.stringify(facility_list);



            let category_list = {
                "category_a": []
            };
            let get_category = document.querySelectorAll('[name="category"]:checked');
            if (get_category.length > 0) {
                get_category.forEach((category) => {
                    category_list.category_a.push(category.value);
                });
                chk_cat_btn.classList.remove('d-none');
            } else {
                chk_cat_btn.classList.add('d-none');
            }

            category_list = JSON.stringify(category_list);

            let features_list = {
                "features_a": []
            };
            let get_features = document.querySelectorAll('[name="features"]:checked');
            if (get_features.length > 0) {
                get_features.forEach((features) => {
                    features_list.features_a.push(features.value);
                });
                features_btn.classList.remove('d-none');
            } else {
                features_btn.classList.add('d-none');
            }

            features_list = JSON.stringify(features_list);

            <?php
            $location = ' ';
            if (isset($_POST['loc'])) {
                $location = $_POST['location'];
            }
            ?>
            let location = '<?php echo $location ?>';


            let xhr = new XMLHttpRequest();
            xhr.open("GET", "ajax/rooms.php?fetch_rooms&facility_list=" + facility_list + "&category_list=" + category_list + "&features_list=" + features_list + "&location=" + location, true);
            xhr.onprogress = function() {
                rooms_data.innerHTML = `<div class="spinner-border text-info mb-3 d-block mx-auto" id="loader" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>`
            }

            xhr.onload = function() {
                rooms_data.innerHTML = this.responseText;

            }

            xhr.send();
        }

        function facilities_clear() {
            let get_facilities = document.querySelectorAll('[name="facilities"]:checked');
            get_facilities.forEach((facility) => {
                facility.checked = false;
            });
            facilities_btn.classList.add('d-none');
            fetch_rooms();
        }

        function cat_clear() {
            let get_category = document.querySelectorAll('[name="category"]:checked');
            get_category.forEach((category) => {
                category.checked = false;
            });
            chk_cat_btn.classList.add('d-none');
            fetch_rooms();
        }

        function features_clear() {
            let get_features = document.querySelectorAll('[name="features"]:checked');
            get_features.forEach((features) => {
                features.checked = false;
            });
            features_btn.classList.add('d-none');
            fetch_rooms();
        }
        // fetch_rooms();
    </script>

    <!--Footer-->
    <?php include("./includes/footer.php"); ?>
    <!--Footer end-->



</body>

</html>

<?php
require('./inc/essentials.php');
require('./inc/db_config.php');
patnarLogin();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Dashboard</title>
    <?php require("./inc/links.php"); ?>
</head>

<body class="bg-light">
   <?php require('./inc/header.php'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-10 ms-auto p-4 overflow-hidden text-center" id="main-content">

                <?php 
                 $q1 = select("SELECT * FROM `pg_patnar` WHERE `id`=?",[$_SESSION['patnarId']],'i');
                 $row_r = mysqli_fetch_assoc($q1);
                 $patnar_name = $row_r['name'];
                 echo "Welcome $patnar_name";
                 
                ?>
            </div>
           
        </div>
    </div>




    <?php require("./inc/scripts.php"); ?>
</body>

</html>
<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
patnarLogin();

  if(isset($_POST['get_all_rooms']))
  {

    $q1 = select("SELECT * FROM `room_patnar` WHERE `patnar_id`=?",[$_SESSION['patnarId']],'i');
    $i=1;
    while($row_r = mysqli_fetch_assoc($q1)){

      $res = select("SELECT * FROM `rooms` WHERE `removed`=? AND `id`=?",[0,$row_r['room_id']],'si');
      
      $data = "";
      while($row = mysqli_fetch_assoc($res))
      {
     
        $p_q = mysqli_query($con,"SELECT p.name FROM `pg_patnar` p INNER JOIN `room_patnar` rp ON p.id = rp.patnar_id WHERE rp.room_id = '$row[id]'");
        $row2 = mysqli_fetch_array($p_q);
        
        if($row['status']==1){
          $status = "<button onclick='toggle_status($row[id],0)' class='btn btn-dark btn-sm shadow-none'>Active</button>";
        }
        else{
          $status = "<button onclick='toggle_status($row[id],1)' class='btn btn-warning btn-sm shadow-none'>Inactive</button>";
        }
       $data.="
       <tr class='align-middle'>
          <td>$i</td>
          <td>$row[name]</td>
          <td>$row[area] sq. ft.</td>
          <td>$row[sharing]</td>
          <td>₹$row[price]</td>
          <td>$row[quantity]</td>
          <td>$row2[name]</td>
          <td>$status</td>
          <td>
              <button type='button' onclick='edit_details($row[id])' class='btn btn-primary shadow-none btn-sm' data-bs-toggle='modal' data-bs-target='#edit-room'>
                <i class='bi bi-pencil-square me-1'></i>
              </button>
          </td>
        </tr>  
       ";
       $i++;
        
      }
      echo $data;
    }


  }

  if(isset($_POST['get_room']))
  {
    $frm_data = filteration($_POST);
    $res1 = select("SELECT * FROM `rooms` WHERE `id`=?",[$frm_data['get_room']],'i');

    $roomdata = mysqli_fetch_assoc($res1);

    $data = ["roomdata"=> $roomdata];
    $data = json_encode($data);
    
    echo $data;
 
  }

  if(isset($_POST['edit_room']))
  {
   
    $frm_data = filteration($_POST);
    $flag = 0;

    $q1 = "UPDATE `rooms` SET `quantity`=? WHERE `id`=?";
    $values = [$frm_data['quantity'],$frm_data['room_id']];
    if(update($q1,$values,'ii')){
        $flag = 1;
    }

    if($flag){
      echo 1;
    }
    else{
      echo 0;
    }

  }




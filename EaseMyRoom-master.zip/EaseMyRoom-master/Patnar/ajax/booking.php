<?php
require('../inc/db_config.php');
require('../inc/essentials.php');
patnarLogin();


  if(isset($_POST['get_users']))
  {
    $q1 = select("SELECT * FROM `room_patnar` WHERE `patnar_id`=?",[$_SESSION['patnarId']],'i');
    $i=1;
    while($row_r = mysqli_fetch_assoc($q1)){
      $q2 = select("SELECT * FROM `rooms` WHERE `removed`=? AND `id`=?",[0,$row_r['room_id']],'si');
      
      while($room_r = mysqli_fetch_assoc($q2)){
        $res = select("SELECT * FROM `booking` WHERE `room_id`=?",[$room_r['id']],'i');
        $data = "";

        while($row = mysqli_fetch_assoc($res))
        {
      
      
          $date = date("d-m-Y",strtotime($row['visit_from'])); 
          $date2 = date("d-m-Y",strtotime($row['visit_to'])); 
       
         
         $data.="
         <tr class='align-middle'>
            <td>$i</td>
            <td>$row[name]</td>
            <td>$row[address]</td>
            <td>$date</td>
            <td>$date2</td>
            <td>$row[room_id]</td>
          </tr>  
         ";
         $i++;
          
        }
        echo $data;
      }  
   }
}



if(isset($_POST['search_user']))
{
  $frm_data = filteration($_POST);

  $q1 = select("SELECT * FROM `room_patnar` WHERE `patnar_id`=?",[$_SESSION['patnarId']],'i');
  $i=1;
  while($row_r = mysqli_fetch_assoc($q1)){
    $q2 = select("SELECT * FROM `rooms` WHERE `removed`=? AND `id`=?",[0,$row_r['room_id']],'si');
    
    while($room_r = mysqli_fetch_assoc($q2)){
      $res = select("SELECT * FROM `booking` WHERE `name` LIKE ? AND `room_id`=?",["%$frm_data[name]%",$room_r['id']],'si');
      $data = "";

      while($row = mysqli_fetch_assoc($res))
      {
    
    
        $date = date("d-m-Y",strtotime($row['visit_from'])); 
        $date2 = date("d-m-Y",strtotime($row['visit_to'])); 
     
       
       $data.="
       <tr class='align-middle'>
          <td>$i</td>
          <td>$row[name]</td>
          <td>$row[address]</td>
          <td>$date</td>
          <td>$date2</td>
          <td>$row[room_id]</td>
        </tr>  
       ";
       $i++;
        
      }
      echo $data;
    }  
 }

}


